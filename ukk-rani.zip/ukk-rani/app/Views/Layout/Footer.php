<footer class="footer mt-auto py-3">
  <div class="container">
    <span class="text-light">By Rani Oktaviani</span>
  </div>
</footer>


<script src="/js/jquery-3.6.0.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/App.js"></script>
</body>

</html>